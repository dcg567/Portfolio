import React from "react";

import styles from "./About.module.css";
import { getImageUrl } from "../../utils";

export const About = () => {
  return (
    <section className={styles.container} id="about">
      <h2 className={styles.title}>About</h2>
      <div className={styles.content}>
        <img
          src={getImageUrl("about/aboutImage.png")}
          alt="Me sitting with a laptop"
          className={styles.aboutImage}
        />
        <ul className={styles.aboutItems}>
          <li className={styles.aboutItem}>
            <img src={getImageUrl("about/cursorIcon.png")} alt="BP" className={styles.aboutImg}/>
            <div className={styles.aboutItemText}>
              <h3>Technical Proficiencies</h3>
              <p>
                Skilled in programming languages and frameworks such as JavaScript, Python, Swift and Angular, with experience in collaborative software projects and agile development.
              </p>
            </div>
          </li>
          <li className={styles.aboutItem}>
            <img src={getImageUrl("about/cursorIcon.png")} alt="BP" className={styles.aboutImg}/>
            <div className={styles.aboutItemText}>
              <h3>Professional Goals</h3>
              <p>
              Dedicated to advancing as a software engineer, with a focus on innovative solutions, continuous improvement, and impactful contributions to technology.
              </p>
            </div>
          </li>
          <li className={styles.aboutItem}>
            <img src={getImageUrl("about/cursorIcon.png")} alt="BP" className={styles.aboutImg}/>
            <div className={styles.aboutItemText}>
              <h3>Work Ethic</h3>
              <p>
              A dedicated and hard-working professional, committed to delivering high-quality results and continuously striving for excellence in all projects.
              </p>
            </div>
          </li>
        </ul>
      </div>
    </section>
  );
};