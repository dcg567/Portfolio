import React from "react";
import styles from "./AIOFitness.module.css"; // Ensure you have a matching CSS file
import { getImageUrl } from "../../../utils";

export const AIOFitness = () => {
  return (
    <div className={styles.container}>
      <h1 className={styles.title}>AIOFitness Project</h1>
      
      <img 
        src={getImageUrl("projects/aiofitness.png")} 
        alt="AIOFitness project screenshot" 
        className={styles.image} 
      />
      
      <p className={styles.description}>
        AIOFitness is a comprehensive app designed to assist users with fitness goals.
      </p>
      
      
    </div>
  );
};
