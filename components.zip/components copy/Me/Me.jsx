import React from "react";

import styles from "./Me.module.css"
import { getImageUrl } from "../../utils";

export const Me = () => {
    return (
    <section className={styles.container}>
        <div className={styles.content}>
            <h1 className={styles.title}>I'm David,</h1>
            <p className={styles.desc}>
            a recent graduate with a Bachelor's Degree in Computer Applications and Software Engineering, awarded with Upper Second-Class Honours (2:1)
            </p>
            <a href="mailto:myemail@email.com" className={styles.contactBtn}> Contact Me</a>
        </div>
        <img src={getImageUrl("me/MeImg.png")} alt="Image of me" className={styles.MeImg}/>
        <div className={styles.topBlur} />
        <div className={styles.bottomBlur} />
    </section>
    );
};